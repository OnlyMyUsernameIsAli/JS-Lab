let num1 = Number(prompt("enter number :"))
let num2 = Number(prompt("enter number :"))
let num3 = Number(prompt("enter number :"))
CenterNum(num1, num2, num3)

// let InNum = Number(prompt("enter number :"))
// Collector(InNum)