let f = prompt("enter fahrenheit :")
let c = (f - 32) * 5 / 9
console.log("result : ", c);