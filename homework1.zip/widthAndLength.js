let width = prompt("enter width :")
let length = prompt("enter length :")
if (width == length) {
    let result1 = width * width
    console.log("result : ", result1);
}
else {
    let result2 = (width * 2) + (length * 2)
    console.log("result : ", result2);
}